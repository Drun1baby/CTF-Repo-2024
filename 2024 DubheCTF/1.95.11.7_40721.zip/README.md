# VulnTagger
Anime images tagger online, but vulnerable. (TSCTF 2024)
