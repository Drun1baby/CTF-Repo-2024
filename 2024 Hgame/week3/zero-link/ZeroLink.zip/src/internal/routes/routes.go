package routes

import (
	"fmt"
	"html/template"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"zero-link/internal/config"
	"zero-link/internal/controller/auth"
	"zero-link/internal/controller/file"
	"zero-link/internal/controller/ping"
	"zero-link/internal/controller/user"
	"zero-link/internal/middleware"
	"zero-link/internal/views"

	"github.com/gin-contrib/sessions"
	"github.com/gin-contrib/sessions/cookie"
	"github.com/gin-gonic/gin"
)

func Run() {
	r := gin.Default()

	html := template.Must(template.New("").ParseFS(views.FS, "*"))
	r.SetHTMLTemplate(html)

	secret := config.Secret.SessionSecret
	store := cookie.NewStore([]byte(secret))
	r.Use(sessions.Sessions("session", store))

	api := r.Group("/api")
	{
		api.GET("/ping", ping.Ping)
		api.POST("/user", user.GetUserInfo)
		api.POST("/login", auth.AdminLogin)

		apiAuth := api.Group("")
		apiAuth.Use(middleware.Auth())
		{
			apiAuth.POST("/upload", file.UploadFile)
			apiAuth.GET("/unzip", file.UnzipPackage)
			apiAuth.GET("/secret", file.ReadSecretFile)
		}
	}

	frontend := r.Group("/")
	{
		frontend.GET("/", func(c *gin.Context) {
			c.HTML(http.StatusOK, "index.html", nil)
		})
		frontend.GET("/login", func(c *gin.Context) {
			c.HTML(http.StatusOK, "login.html", nil)
		})

		frontendAuth := frontend.Group("")
		frontendAuth.Use(middleware.Auth())
		{
			frontendAuth.GET("/manager", func(c *gin.Context) {
				c.HTML(http.StatusOK, "manager.html", nil)
			})
		}
	}

	quit := make(chan os.Signal)
	signal.Notify(quit, os.Interrupt)

	go func() {
		<-quit
		err := os.Remove(filepath.Join(".", "sqlite.db"))
		if err != nil {
			fmt.Println("Failed to delete sqlite.db:", err)
		} else {
			fmt.Println("sqlite.db deleted")
		}
		os.Exit(0)
	}()

	r.Run(":8000")
}
