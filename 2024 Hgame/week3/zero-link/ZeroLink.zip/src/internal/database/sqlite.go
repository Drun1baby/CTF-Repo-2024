package database

import (
	"log"
	"zero-link/internal/config"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var db *gorm.DB

type User struct {
	gorm.Model
	Username string `gorm:"not null;column:username;unique"`
	Password string `gorm:"not null;column:password"`
	Token    string `gorm:"not null;column:token"`
	Memory   string `gorm:"not null;column:memory"`
}

func init() {
	databaseLocation := config.Sqlite.Location

	var err error
	db, err = gorm.Open(sqlite.Open(databaseLocation), &gorm.Config{})
	if err != nil {
		panic("Cannot connect to SQLite: " + err.Error())
	}

	err = db.AutoMigrate(&User{})
	if err != nil {
		panic("Failed to migrate database: " + err.Error())
	}

	users := []User{
		{Username: "Admin", Token: "0000", Password: "Admin password is here", Memory: "Keep Best Memory!!!"},
		{Username: "Taka", Token: "4132", Password: "newfi443543", Memory: "Love for pixel art."},
		{Username: "Tom", Token: "8235", Password: "ofeni3525", Memory: "Family is my treasure"},
		{Username: "Alice", Token: "1234", Password: "abcde12345", Memory: "Graduating from college"},
		{Username: "Bob", Token: "5678", Password: "fghij67890", Memory: "Winning a championship in sports"},
		{Username: "Charlie", Token: "9012", Password: "klmno12345", Memory: "Traveling to a foreign country for the first time"},
		{Username: "David", Token: "3456", Password: "pqrst67890", Memory: "Performing on stage in a theater production"},
		{Username: "Emily", Token: "7890", Password: "uvwxy12345", Memory: "Meeting my favorite celebrity"},
		{Username: "Frank", Token: "2345", Password: "zabcd67890", Memory: "Overcoming a personal challenge"},
		{Username: "Grace", Token: "6789", Password: "efghi12345", Memory: "Completing a marathon"},
		{Username: "Henry", Token: "0123", Password: "jklmn67890", Memory: "Becoming a parent"},
		{Username: "Ivy", Token: "4567", Password: "opqrs12345", Memory: "Graduating from high school"},
		{Username: "Jack", Token: "8901", Password: "tuvwx67890", Memory: "Starting my own business"},
		{Username: "Kelly", Token: "2345", Password: "yzabc12345", Memory: "Learning to play a musical instrument"},
		{Username: "Liam", Token: "6789", Password: "defgh67890", Memory: "Winning a scholarship for higher education"},
	}
	for _, user := range users {
		result := db.Create(&user)
		if result.Error != nil {
			panic("Failed to create user: " + result.Error.Error())
		}
	}
}

func GetPasswordByUsername(username string) (string, error) {
	var user User
	err := db.Where("username = ?", username).First(&user).Error
	if err != nil {
		log.Println("Cannot get password: " + err.Error())
		return "", err
	}
	return user.Password, nil
}

func GetUserByUsernameOrToken(username string, token string) (*User, error) {
	var user User
	query := db
	if username != "" {
		query = query.Where(&User{Username: username})
	} else {
		query = query.Where(&User{Token: token})
	}
	err := query.First(&user).Error
	if err != nil {
		log.Println("Cannot get user: " + err.Error())
		return nil, err
	}
	return &user, nil
}
