package user

import (
	"net/http"
	"zero-link/internal/database"

	"github.com/gin-gonic/gin"
)

type UserInfoResponse struct {
	Code    int            `json:"code"`
	Message string         `json:"message"`
	Data    *database.User `json:"data"`
}

func GetUserInfo(c *gin.Context) {
	var req struct {
		Username string `json:"username"`
		Token    string `json:"token"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, UserInfoResponse{
			Code:    http.StatusBadRequest,
			Message: "Invalid request body",
			Data:    nil,
		})
		return
	}

	if req.Username == "Admin" || req.Token == "0000" {
		c.JSON(http.StatusForbidden, UserInfoResponse{
			Code:    http.StatusForbidden,
			Message: "Forbidden",
			Data:    nil,
		})
		return
	}

	user, err := database.GetUserByUsernameOrToken(req.Username, req.Token)
	if err != nil {
		c.JSON(http.StatusInternalServerError, UserInfoResponse{
			Code:    http.StatusInternalServerError,
			Message: "Failed to get user",
			Data:    nil,
		})
		return
	}

	if user == nil {
		c.JSON(http.StatusNotFound, UserInfoResponse{
			Code:    http.StatusNotFound,
			Message: "User not found",
			Data:    nil,
		})
		return
	}

	response := UserInfoResponse{
		Code:    http.StatusOK,
		Message: "Ok",
		Data:    user,
	}

	c.JSON(http.StatusOK, response)
}
