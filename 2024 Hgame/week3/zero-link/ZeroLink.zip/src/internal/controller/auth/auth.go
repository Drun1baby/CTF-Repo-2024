package auth

import (
	"encoding/json"
	"net/http"
	"zero-link/internal/database"

	"github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
)

type AuthResponse struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

func AdminLogin(c *gin.Context) {
	var req struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}

	err := json.NewDecoder(c.Request.Body).Decode(&req)
	if err != nil {
		c.JSON(http.StatusBadRequest, AuthResponse{
			Code:    http.StatusBadRequest,
			Message: "Invalid request body",
		})
		return
	}

	if req.Username != "Admin" {
		c.JSON(http.StatusForbidden, AuthResponse{
			Code:    http.StatusForbidden,
			Message: "Only Admin is allowed to login",
		})
		return
	}

	password, err := database.GetPasswordByUsername(req.Username)
	if err != nil {
		c.JSON(http.StatusInternalServerError, AuthResponse{
			Code:    http.StatusInternalServerError,
			Message: "Failed to get password",
		})
		return
	}

	if req.Password != password {
		c.JSON(http.StatusUnauthorized, AuthResponse{
			Code:    http.StatusUnauthorized,
			Message: "Invalid password",
		})
		return
	}

	session := sessions.Default(c)
	session.Set("username", "Admin")
	err = session.Save()
	if err != nil {
		return
	}

	c.JSON(http.StatusOK, AuthResponse{
		Code:    http.StatusOK,
		Message: "Login successful",
	})
}
