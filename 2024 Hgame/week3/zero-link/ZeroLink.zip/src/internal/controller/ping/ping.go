package ping

import "github.com/gin-gonic/gin"

type Response struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

func Ping(c *gin.Context) {
	response := Response{
		Code:    200,
		Message: "pong!",
	}

	c.JSON(response.Code, response)
}
