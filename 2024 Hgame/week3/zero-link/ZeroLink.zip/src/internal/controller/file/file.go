package file

import (
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"zero-link/internal/util"

	"github.com/gin-gonic/gin"
)

type FileResponse struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    string `json:"data"`
}

func UploadFile(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		c.JSON(http.StatusBadRequest, FileResponse{
			Code:    http.StatusBadRequest,
			Message: "No file uploaded",
			Data:    "",
		})
		return
	}

	ext := filepath.Ext(file.Filename)
	if (ext != ".zip") || (file.Header.Get("Content-Type") != "application/zip") {
		c.JSON(http.StatusBadRequest, FileResponse{
			Code:    http.StatusBadRequest,
			Message: "Only .zip files are allowed",
			Data:    "",
		})
		return
	}

	filename := "/app/uploads/" + file.Filename

	if _, err := os.Stat(filename); err == nil {
		err := os.Remove(filename)
		if err != nil {
			c.JSON(http.StatusInternalServerError, FileResponse{
				Code:    http.StatusInternalServerError,
				Message: "Failed to remove existing file",
				Data:    "",
			})
			return
		}
	}

	err = c.SaveUploadedFile(file, filename)
	if err != nil {
		c.JSON(http.StatusInternalServerError, FileResponse{
			Code:    http.StatusInternalServerError,
			Message: "Failed to save file",
			Data:    "",
		})
		return
	}

	c.JSON(http.StatusOK, FileResponse{
		Code:    http.StatusOK,
		Message: "File uploaded successfully",
		Data:    filename,
	})
}

func UnzipPackage(c *gin.Context) {
	files, err := filepath.Glob("/app/uploads/*.zip")
	if err != nil {
		c.JSON(http.StatusInternalServerError, FileResponse{
			Code:    http.StatusInternalServerError,
			Message: "Failed to get list of .zip files",
			Data:    "",
		})
		return
	}

	for _, file := range files {
		cmd := exec.Command("unzip", "-o", file, "-d", "/tmp/")
		if err := cmd.Run(); err != nil {
			c.JSON(http.StatusInternalServerError, FileResponse{
				Code:    http.StatusInternalServerError,
				Message: "Failed to unzip file: " + file,
				Data:    "",
			})
			return
		}
	}

	c.JSON(http.StatusOK, FileResponse{
		Code:    http.StatusOK,
		Message: "Unzip completed",
		Data:    "",
	})
}

func ReadSecretFile(c *gin.Context) {
	secretFilepath := "/app/secret"
	content, err := util.ReadFileToString(secretFilepath)
	if err != nil {
		c.JSON(http.StatusInternalServerError, FileResponse{
			Code:    http.StatusInternalServerError,
			Message: "Failed to read secret file",
			Data:    "",
		})
		return
	}

	secretContent, err := util.ReadFileToString(content)
	if err != nil {
		c.JSON(http.StatusInternalServerError, FileResponse{
			Code:    http.StatusInternalServerError,
			Message: "Failed to read secret file content",
			Data:    "",
		})
		return
	}

	c.JSON(http.StatusOK, FileResponse{
		Code:    http.StatusOK,
		Message: "Secret content read successfully",
		Data:    secretContent,
	})
}
