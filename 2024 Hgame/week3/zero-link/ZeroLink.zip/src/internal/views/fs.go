package views

import "embed"

//go:embed *.html
var FS embed.FS
