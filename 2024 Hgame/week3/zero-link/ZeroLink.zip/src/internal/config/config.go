package config

import "github.com/pelletier/go-toml"

var Sqlite struct {
	Location string `toml:"location"`
}

var Secret struct {
	SessionSecret string `toml:"session_secret"`
}

var configFile = "config.toml"

func init() {
	conf, err := toml.LoadFile(configFile)
	if err != nil {
		panic("Failed to open config file")
	}

	if err := conf.Get("sqlite").(*toml.Tree).Unmarshal(&Sqlite); err != nil {
		panic("Mapping [sqlite] section")
	}
	if err := conf.Get("secret").(*toml.Tree).Unmarshal(&Secret); err != nil {
		panic("Mapping [secret] section")
	}
}
