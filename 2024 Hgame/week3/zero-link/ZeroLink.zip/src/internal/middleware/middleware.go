package middleware

import (
	"net/http"

	"github.com/gin-contrib/sessions"
	"github.com/gin-gonic/gin"
)

func Auth() gin.HandlerFunc {
	return func(c *gin.Context) {
		session := sessions.Default(c)
		username, exist := session.Get("username").(string)
		if !exist || username == "" {
			c.Redirect(http.StatusFound, "/login")
			c.Abort()
		}

		c.Next()
	}
}
