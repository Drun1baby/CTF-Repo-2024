package util

import (
	"os"
	"strings"
)

func ReadFileToString(filepath string) (string, error) {
	content, err := os.ReadFile(filepath)
	if err != nil {
		return "", err
	}

	contentStr := strings.TrimSuffix(string(content), "\n")
	return contentStr, nil
}
