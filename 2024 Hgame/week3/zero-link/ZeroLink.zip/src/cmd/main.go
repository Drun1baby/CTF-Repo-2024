package main

import (
	"zero-link/internal/routes"
)

func main() {
	routes.Run()
}
