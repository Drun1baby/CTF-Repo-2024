export default [
    {
        "username": "mrekk",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e6-1f1fa.svg",
        "performance": 26280,
        "playCount": 179497
    },
    {
        "username": "Accolibed",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1ec-1f1e7.svg",
        "performance": 25697,
        "playCount": 308266
    },
    {
        "username": "lifeline",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1ee-1f1e9.svg",
        "performance": 23647,
        "playCount": 237898
    },
    {
        "username": "gnahus",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f5-1f1f1.svg",
        "performance": 22089,
        "playCount": 135516
    },
    {
        "username": "ninerik",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f3-1f1f4.svg",
        "performance": 21731,
        "playCount": 165331
    },
    {
        "username": "Chicony",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f7-1f1fa.svg",
        "performance": 21222,
        "playCount": 63117
    },
    {
        "username": "-Flary",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1fa-1f1f8.svg",
        "performance": 20743,
        "playCount": 138659
    },
    {
        "username": "cloutiful",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f6-1f1e6.svg",
        "performance": 20737,
        "playCount": 129597
    },
    {
        "username": "NyanPotato",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f7-1f1fa.svg",
        "performance": 20353,
        "playCount": 163117
    },
    {
        "username": "Zoomer",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f3-1f1ff.svg",
        "performance": 20198,
        "playCount": 247772
    },
    {
        "username": "aetrna",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e8-1f1e6.svg",
        "performance": 20025,
        "playCount": 165149
    },
    {
        "username": "shimon",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f2-1f1fe.svg",
        "performance": 19777,
        "playCount": 269086
    },
    {
        "username": "sytho",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1fa-1f1f8.svg",
        "performance": 19757,
        "playCount": 343277
    },
    {
        "username": "maliszewski",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f5-1f1f1.svg",
        "performance": 19748,
        "playCount": 131858
    },
    {
        "username": "WhiteCat",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e9-1f1ea.svg",
        "performance": 19657,
        "playCount": 48012
    },
    {
        "username": "Utami",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1fa-1f1f8.svg",
        "performance": 19600,
        "playCount": 144443
    },
    {
        "username": "Freddie Benson",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1fa-1f1f8.svg",
        "performance": 19575,
        "playCount": 86828
    },
    {
        "username": "enri",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f5-1f1ed.svg",
        "performance": 19552,
        "playCount": 226078
    },
    {
        "username": "WindowLife",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1fa-1f1f8.svg",
        "performance": 19541,
        "playCount": 150110
    },
    {
        "username": "aimbotcone",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e9-1f1ea.svg",
        "performance": 19441,
        "playCount": 167355
    },
    {
        "username": "Mathi",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e8-1f1f1.svg",
        "performance": 19435,
        "playCount": 251664
    },
    {
        "username": "ASecretBox",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e6-1f1fa.svg",
        "performance": 19205,
        "playCount": 245332
    },
    {
        "username": "Rektygon",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1fa-1f1f8.svg",
        "performance": 19178,
        "playCount": 144491
    },
    {
        "username": "ciru",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1fa-1f1f8.svg",
        "performance": 19137,
        "playCount": 252655
    },
    {
        "username": "rayuii",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e8-1f1e6.svg",
        "performance": 19108,
        "playCount": 272238
    },
    {
        "username": "Kamensh1k",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f0-1f1ff.svg",
        "performance": 19100,
        "playCount": 110621
    },
    {
        "username": "Aricin",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1fa-1f1f8.svg",
        "performance": 19084,
        "playCount": 187059
    },
    {
        "username": "MINHOCA LOKA",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e7-1f1f7.svg",
        "performance": 18826,
        "playCount": 185710
    },
    {
        "username": "ChocoPafe",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1ef-1f1f5.svg",
        "performance": 18821,
        "playCount": 220472
    },
    {
        "username": "worst hr player",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f0-1f1f7.svg",
        "performance": 18750,
        "playCount": 119129
    },
    {
        "username": "[MG]Arnold24x24",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f5-1f1ea.svg",
        "performance": 18738,
        "playCount": 184115
    },
    {
        "username": "Zylice",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e8-1f1e6.svg",
        "performance": 18702,
        "playCount": 109037
    },
    {
        "username": "tomasz chic",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f5-1f1f1.svg",
        "performance": 18693,
        "playCount": 128102
    },
    {
        "username": "Fakercambing",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e8-1f1f1.svg",
        "performance": 18566,
        "playCount": 168161
    },
    {
        "username": "Milkteaism",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f5-1f1ed.svg",
        "performance": 18547,
        "playCount": 118109
    },
    {
        "username": "Rafis",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f5-1f1f1.svg",
        "performance": 18526,
        "playCount": 368871
    },
    {
        "username": "rudj",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1ec-1f1e7.svg",
        "performance": 18499,
        "playCount": 339116
    },
    {
        "username": "Vaxei",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1fa-1f1f8.svg",
        "performance": 18487,
        "playCount": 168290
    },
    {
        "username": "[Karcher]",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f0-1f1f7.svg",
        "performance": 18479,
        "playCount": 186319
    },
    {
        "username": "Reused",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1fa-1f1f8.svg",
        "performance": 18437,
        "playCount": 140149
    },
    {
        "username": "his kitten",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e8-1f1e6.svg",
        "performance": 18394,
        "playCount": 95170
    },
    {
        "username": "kazamabc",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1ea-1f1f8.svg",
        "performance": 18383,
        "playCount": 297999
    },
    {
        "username": "aknzx",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1e6-1f1fa.svg",
        "performance": 18325,
        "playCount": 77409
    },
    {
        "username": "luciano",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f3-1f1f1.svg",
        "performance": 18263,
        "playCount": 291936
    },
    {
        "username": "Ivaxa",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f5-1f1f1.svg",
        "performance": 18191,
        "playCount": 78309
    },
    {
        "username": "MINIONPEPSI2013",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1ea-1f1f8.svg",
        "performance": 18165,
        "playCount": 245458
    },
    {
        "username": "Plasma",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1ec-1f1e7.svg",
        "performance": 18125,
        "playCount": 97802
    },
    {
        "username": "_maika",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f0-1f1f7.svg",
        "performance": 18039,
        "playCount": 68185
    },
    {
        "username": "FlyingTuna",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1f0-1f1f7.svg",
        "performance": 18038,
        "playCount": 135385
    },
    {
        "username": "mcy4",
        "flag": "https://osu.ppy.sh/assets/images/flags/1f1ed-1f1f0.svg",
        "performance": 18025,
        "playCount": 263261
    }
]