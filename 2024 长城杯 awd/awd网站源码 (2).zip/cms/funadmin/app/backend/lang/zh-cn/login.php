<?php

return [

//    登录
    'Keep Login'=>"保持登录",
    'Captcha error' => '验证码错误',
    'Login Success' => '登录成功',
    'Login Failed' => '登录失败',
    'Account is disabled' => '账号禁用',
    'Account is not accessed' => '账号未成功接入',
    'Please check username or password' => '请检查用户名或密码',
];