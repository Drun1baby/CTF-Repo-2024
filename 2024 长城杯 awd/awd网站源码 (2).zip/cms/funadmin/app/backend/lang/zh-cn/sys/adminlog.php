<?php

return [
    'Admin Username'=>'管理员名',
    'Method'=>'方式',
    'Log Addr'=>'日志地址',
    'Log Content'=>'日志内容',
    'Log Title'=>'日志标题',
    'Log Agent'=>'代理',
    'Ip'=>'ip地址',
];