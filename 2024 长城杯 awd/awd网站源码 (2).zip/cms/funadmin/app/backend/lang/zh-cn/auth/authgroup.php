<?php

return [
    'access group'=>'分配权限',
    'GroupName'=>'组名',
    'AuthGroupPid'=>'权限组ID',
    'Module'=>'模块',
    "SupperAdmin cannot edit"=>'超管组不能被编辑',

];