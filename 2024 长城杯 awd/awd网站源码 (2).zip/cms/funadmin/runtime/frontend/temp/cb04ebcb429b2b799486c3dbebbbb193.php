<?php /*a:1:{s:48:"/var/www/html/app/frontend/view/index/index.html";i:1686239151;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>FunAdmin - 基于ThinkPHP6,layui开发的敏捷通用的后台管理框架</title>
    <meta name="keywords" content="FunAdmin,TP6后台管理系统,ThinkPHP6通用后台,ThinkPHP框架,Layui后台,Thinkphp小程序,小程序,CMS,电商，微信,PHP插件应用市场,支持PHP8.0, ">
    <meta name="description"，
          content="FunAdmin支持PHP8.0的系统, 是一款采用 layui开发的敏捷的后台管理框架,基于thinkphp6 ,easywechat,开发的cms后台管理系统,thinkphp,shop,cms,php后台管理系统,cms,cms系统,restful api,thinkphp后台管理系统">
    <meta name="author" content="FunAdmin">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css"/>
    <link rel="stylesheet" href="/static/frontend/css/index.css?t=<?php echo time(); ?>" media="all">
    <script src="/static/plugins/layui/layui.js"></script>
    <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->
</head>
<body class="site-home" id="LAY_home">
<section>
    <div class="layui-header header header-index layui-bg-black" autumn>
        <div class="layui-main">
            <a title='cms' class="logo" style="font-size: 1.9em;line-height: 1em;" href="/">
                FunAdmin
            </a>
            <div class="layui-form component" lay-filter="LAY-site-header-component"></div>
            <ul class="layui-nav">
                <li class="layui-nav-item ">
                    <a href="https://www.FunAdmin.com/frontend/plugins" site-event="contactInfo" target="_blank">插件
                        <span class="layui-badge">新</span>
                    </a>
                </li>
                <li class="layui-nav-item ">
                    <a href="https://bbs.FunAdmin.com/" site-event="contactInfo" target="_blank">社区
                        <span class="layui-badge-dot"></span>
                    </a>
                </li>
                <li class="layui-nav-item layui-hide-xs">
                    <a href="https://jq.qq.com/?_wv=1027&k=GOakxsp6" site-event="contactInfo" target="_blank">QQ
                        群</a>
                </li>
                <li class="layui-nav-item layui-hide-xs">
                    <a href="http://layui.funadmin.com/web" target="_blank">Layui
                        <!-- <span class="layui-badge-dot"></span> --></a>
                </li>
                <li class="layui-nav-item layui-hide-xs">
                    <a href="http://doc.funadmin.com" target="_blank">文档
                        <!-- <span class="layui-badge-dot"></span> --></a>
                </li>
                <li class="layui-nav-item layui-hide-xs">
                    <a href="https://www.funadmin.com/version/index"  target="_blank">版本
                        <!-- <span class="layui-badge-dot"></span> --></a>
                </li>
                <!--<li class="layui-nav-item layui-hide-xs">-->
                <!--    <a href="https://gitee.com/funadmin/funadmin" target="_blank">下载-->
                <!-- <span class="layui-badge-dot"></span> --></a>
                <!--</li>-->
                <?php if(session('member')): ?>
                <li class="layui-nav-item layui-hide-xs">
                    <a href="<?php echo __u('member/index'); ?>" target="_blank" class="layui-tips">会员中心
                        <!-- <span class="layui-badge-dot"></span> --></a>
                </li>
                <?php else: ?>
                <li class="layui-nav-item layui-hide-xs">
                    <a href="<?php echo __u('login/index'); ?>" target="_blank" class="layui-tips">登录
                        <span class="layui-badge-dot"></span></a>
                </li>
                <?php endif; ?>

                <!--                <li class="layui-nav-item ">-->
                <!--                    <a href="<?php echo __u('member/index'); ?>" target="_blank" class="layui-tips">会员-->
                <!--                        &lt;!&ndash; <span class="layui-badge-dot"></span> &ndash;&gt;</a>-->
                <!--                </li>-->

            </ul>
        </div>
    </div>

</section>

<section>
    <div class="site-banner">
        <div class="site-banner-bg">
            <div class="overlay"></div>
        </div>
        <div class="site-banner-main">
            <div class="site-zfj site-zfj-anim layui-hide-xs">
                <!--                <i class="layui-icon" style="color: #fff; color: rgba(255,255,255,.7);"></i>-->
            </div>
            <div class="layui-anim site-desc site-desc-anim">
                <p class="web-font-desc">FunAdmin</p>
                <p class="web-font-desc " style="font-size: 26px;margin-bottom:25px; ">为梦想而创作：支持PHP8.0的系统</p>
                <p class="web-font-desc layui-hide-xs" style="font-size: 16px;">框架主要使用ThinkPHP6.X + Layui 拥有完善的权限的管理模块以及插件的开发方式，让你开发起来更加简单。</p>
                <!--                <cite></cite>-->
            </div>
            <div class="site-download">
                <a href="https://gitee.com/funadmin/funadmin" class="layui-inline site-down"
                   target="_blank">
                    <cite class="layui-icon"></cite>
                    立即下载
                </a>
            </div>
            <div class="site-version">
                <span>当前版本：<cite class="site-showv"><?php echo config('funadmin.version'); ?></cite></span>
                <span><a href="<?php echo __u('version/index'); ?>" rel="nofollow" target="_blank">更新日志</a></span>
                <!--<span>下载量：<em class="site-showdowns">1894161</em></span>-->
            </div>
            <div class="site-banner-other">
                <a href="https://gitee.com/funadmin/funadmin.git" target="_blank" class="site-star">
                    <i class="layui-icon"></i>
                    Star <cite id="getStars"></cite>
                </a>
                <a href="https://gitee.com/funadmin/funadmin" target="_blank" rel="nofollow"
                   class="site-fork">
                    <i class="layui-icon"></i>
                    Fork
                </a>
                <a href="https://gitee.com/funadmin/funadmin" target="_blank" rel="nofollow" class="site-fork">
                    码云
                </a>
            </div>
        </div>
    </div>
</section>
<section class="container">
    <div class="layui-main">
        <div class="section-title">
            <h2>产品优势</h2>
            <p>拥有多年管理系统产品开发经验</p>
        </div>
        <div class="layui-container">
            <div class="layui-row">
                <div class="layui-col-md4 layui-col-sm6">
                    <fieldset class="layui-elem-field layui-field-title" title="FunAadmin thinkphp后台管理系统">
                        <div class="icon"><i class="layui-icon layui-icon-fonts-code"></i></div>
                        <legend>大道至简</legend>
                        <p>插件式开发，系统保留权限等基础功能，<br>
                            其他全部采用插件式开发，<br>
                            开发者只需要开发插件,提高复用率，让更多的用户可以使用
                        </p>
                    </fieldset>
                </div>
                <div class="layui-col-md4 layui-col-sm6">
                    <fieldset class="layui-elem-field layui-field-title" title="FunAadmin thinkphp后台管理系统">
                        <div class="icon"><i class="layui-icon layui-icon-fire"></i></div>
                        <legend>友好的二次开发</legend>
                        <p>FunAadmin允许进行二次开发，<br>
                            并用在企业或者个人项目中,<br>
                            集合layui，thinkphp6,
                            restful api</p>
                    </fieldset>
                </div>
                <div class="layui-col-md4 layui-col-sm6">
                    <fieldset class="layui-elem-field layui-field-title" title="FunAadmin thinkphp后台管理系统">
                        <div class="icon"><i class="layui-icon layui-icon-praise"></i></div>
                        <legend>权限控制</legend>
                        <p>基于完善的权限控制管理、<br>
                            无限父子级权限分组、<br>
                            可自由分配子级权限。</p>
                    </fieldset>
                </div>
                <div class="layui-col-md4 layui-col-sm6">
                    <fieldset class="layui-elem-field layui-field-title" title="FunAadmin thinkphp后台管理系统">
                        <div class="icon"><i class="layui-icon layui-icon-app"></i></div>
                        <legend>插件式开发</legend>
                        <p>
                            模块采用插件式开发<br>
                            一键安装卸载，<br>
                            省去大量工作<br>
                            插件市场大量免费插件
                        </p>
                    </fieldset>
                </div>
                <div class="layui-col-md4 layui-col-sm6">
                    <fieldset class="layui-elem-field layui-field-title" title="FunAadmin thinkphp后台管理系统">
                        <div class="icon"><i class="layui-icon layui-icon-rmb"></i></div>
                        <legend>低成本</legend>
                        <p>界面美观，免去设计工作<br>
                            开箱即用，省去项目前期搭建时间<br>
                            使用requirejs 一个命令打包js,css文件
                        </p>
                    </fieldset>
                </div>
                <div class="layui-col-md4 layui-col-sm6">
                    <fieldset class="layui-elem-field layui-field-title" title="FunAadmin thinkphp后台管理系统">
                        <div class="icon"><i class="layui-icon layui-icon-cellphone"></i></div>
                        <legend>丰富的表单组件</legend>
                        <p>支持超多表单组件，<br>
                            覆盖几乎所有的使用场景，<br>
                            并且支持自定义扩展其它任何组件以满足你的需求。</p>
                    </fieldset>
                </div>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="fly-footer layui-footer">
        <p>
            <a href="javascript:;" target="_blank">Powered by FunAdmin</a>  <a href="javascript:;" target="_blank">2018-2028 &copy;</a></p>
        <p>
            <a href="javascript:;" >版权所有:FunAdmin版权所有</a>
            <a href="http://www.funadmin.com/" title="funadmin官网">funadmin官网</a>
            <a href="https://jq.qq.com/?_wv=1027&k=5wj2Wdy" title="获取源码">社区插件授权获取源码</a>
            <a href="http://www.Funadmin.com/" title="开源后台管理系统">开源后台管理系统</a>
            <a href="https://demo.funadmin.com/admin.php" title="php cms 后台管理系统">php后台管理系统</a>
            <a href="http://www.beian.miit.gov.cn">粤ICP备19106066号</a>
        </p>
    </div>

</section>

<script>
    layui.use(['layer', 'jquery'], function () {
        var $ = layui.jquery,
            layer = layui.layer;
        $('.layui-tips').hover(function () {
            layer.tips('账号admin,密码123456');
        })
    })
</script>
<script>
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
        hm.src = "https://hm.baidu.com/hm.js?8dcaf664827c0e8ae52287ebb2411aed";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();
</script>

</body>
</html>
