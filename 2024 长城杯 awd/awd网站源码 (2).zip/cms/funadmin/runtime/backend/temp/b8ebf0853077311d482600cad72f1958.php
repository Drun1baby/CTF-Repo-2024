<?php /*a:1:{s:47:"/var/www/html/app/backend/view/index/index.html";i:1686239151;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo syscfg('site','sys_name'); ?>后台管理</title>
    <meta name="renderer" content="webkit">
    <meta property="og:keywords" content="<?php echo syscfg('site','site_seo_keywords'); ?>" />
    <meta property="og:description" content="<?php echo syscfg('site','site_seo_desc'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="referrer" content="origin" />
    <meta name="viewport"  content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no"  >
    <link rel="stylesheet" href="/static/plugins/layui/css/layui.css" media="all" />
    <link rel="stylesheet" href="/static/backend/css/style.css?v=<?php echo syscfg('site','site_version'); ?>" media="all">
    <link rel="stylesheet" href="/static/backend/css/fun.css?v=<?php echo syscfg('site','site_version'); ?>" media="all">
    <link rel="stylesheet" href="/static/backend/css/global.css?v=<?php echo syscfg('site','site_version'); ?>" media="all" />

    <?php echo token_meta(); ?>
    <style id="fun-bg-color">
    </style>
</head>
<script>
    window.Config = <?php echo json_encode($config); ?>;
    window.Config.formData = <?php echo isset($formData)?(json_encode($formData)):'""'; ?>,
    window.STATIC ='/static'
    window.PLUGINS = '/static/plugins';
</script>

<?php  $site_theme = syscfg('site','site_theme'); $theme = "index/theme".$site_theme; ?>


<body class="layui-layout-body  menu<?php echo htmlentities($site_theme); ?>">
<div id="fun-app" class="fun-app">
    <!--        加载层-->
    <div class="fun-loading">
        <div class="loading">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <div class="layui-layout layui-layout-admin" >

        <?php  echo \think\facade\View::fetch($theme);  ?>
        <!-- 遮罩 -->
        <div class="layui-body-shade" lay-event="shade"></div>
        <!--手机导航-->
        <div class="layui-site-mobile layui-hide-lg layui-hide-md" lay-event="flexible"><i class="layui-icon layui-icon-right"></i></div>
        <!-- 底部固定区域 -->
        <div class="layui-footer">
            <?php echo htmlentities($config['site']['site_copyright']); ?> <span class="pull-right">v<?php echo config('funadmin.version'); ?></span>
        </div>
    </div>


</div>
</body>
</html>
<script src="/static/plugins/layui/layui.js" charset="utf-8"></script>
<script defer src="/static/require.min.js?v=<?php echo syscfg('site','site_version'); ?>" data-main="/static/js/require-backend<?php echo syscfg('site','app_debug')?'':'.min'; ?>.js?v=<?php echo syscfg('site','app_debug')?time():syscfg('site','site_version'); ?>" charset="utf-8"></script>
