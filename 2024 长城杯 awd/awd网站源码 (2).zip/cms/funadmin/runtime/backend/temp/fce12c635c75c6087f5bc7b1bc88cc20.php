<?php /*a:3:{s:47:"/var/www/html/app/backend/view/addon/index.html";i:1686239151;s:47:"/var/www/html/app/backend/view/layout/main.html";i:1686239151;s:51:"/var/www/html/app/backend/view/layout/logintpl.html";i:1686239151;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo syscfg('site','sys_name'); ?>后台管理</title>
    <meta property="og:keywords" content="<?php echo syscfg('site','site_seo_keywords'); ?>" />
    <meta property="og:description" content="<?php echo syscfg('site','site_seo_desc'); ?>" />
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="referrer" content="never">
    <meta name="format-detection" content="telephone=no">
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="/static/plugins/layui/css/layui.css" media="all" />
    <link rel="stylesheet" href="/static/backend/css/comm.css?v=<?php echo syscfg('site','site_version'); ?>" media="all">
    <link rel="stylesheet" href="/static/backend/css/global.css?v=<?php echo syscfg('site','site_version'); ?>" media="all" />
    <script src="/static/plugins/jquery/jquery-3.6.0.min.js"></script>
    <script src="/static/plugins/layui/layui.js" charset="utf-8"></script>
    <?php echo token_meta(); ?>
</head>
<script>
    window.Config = <?php echo json_encode($config); ?>;
    window.Config.formData = <?php echo isset($formData)?(json_encode($formData)):'""'; ?>,
    window.STATIC ='/static'
    window.PLUGINS = '/static/plugins';
</script>
<body style="padding: 10px;background: #fff">

<div class="fun-container" id="app" style="">

<div class="layui-tab layui-tab-card" lay-filter="tab">
    <ul class="layui-tab-title" data-field="cateid">
        <li class="layui-this" data-value="" lay-event="tabswitch">全部</li>
        <?php if(is_array($cateList) || $cateList instanceof \think\Collection || $cateList instanceof \think\Paginator): $i = 0; $__LIST__ = $cateList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <li data-value="<?php echo htmlentities($vo['id']); ?>" lay-event="tabswitch"><?php echo htmlentities($vo['title']); ?></li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </ul>
</div>
<table class="layui-table" id="list" lay-filter="list"
      data-node-add="<?php echo auth(__u('add')); ?>"
      data-node-edit="<?php echo auth(__u('edit')); ?>"
      data-node-delete="<?php echo auth(__u('delete')); ?>"
      data-node-destroy="<?php echo auth(__u('destroy')); ?>"
      data-node-modify="<?php echo auth(__u('modify')); ?>"
      data-node-recycle="<?php echo auth(__u('recycle')); ?>"
      data-node-restore="<?php echo auth(__u('restore')); ?>"
      data-node-import="<?php echo auth(__u('import')); ?>"
      data-node-export="<?php echo auth(__u('export')); ?>"
      data-node-install="<?php echo auth(__u('install')); ?>"
      data-node-localinstall="<?php echo auth(__u('localinstall')); ?>"
      data-node-uninstall="<?php echo auth(__u('uninstall')); ?>"
      data-node-config="<?php echo auth(__u('config')); ?>"
>
</table>
<!--<table  id="list" lay-filter="list"></table>-->
<!--登陆页面-->
<script type="text/html" id="login_tpl">
  <style>
    .header.layui-card-body{
      background-color: #fcf8e3;
      border-color: #faf3cd;
      color: #c09853;
      padding: 20px;
    }
  </style>
  <div>
    <div class="layui-card">
      <div class="layui-card-body header" >
          温馨提示
          <br>
          此处账号为: <a class="layui-font-14" target="_blank" href="http://www.FunAdmin.com">《FunAdmin云平台账号》</a>
      </div>
      <form class="layui-form" action="">
      <div class="layui-card-body">
          <div class="layui-form-item">
            <div class="layui-inline-block layui-input-wrap layui-input-wrap-prefix">
              <div class="layui-input-prefix">
                <i class="layui-icon layui-icon-username"></i>
              </div>
              <input id="inputUsername" type="text" name="username" value="" lay-verify="required" placeholder="<?php echo lang('UserName Or Email'); ?>" autocomplete="off" class="layui-input" lay-affix="clear">
            </div>
          </div>
          <div class="layui-form-item">
            <div class="layui-inline-block layui-input-wrap layui-input-wrap-prefix">
              <div class="layui-input-prefix">
                <i class="layui-icon layui-icon-password"></i>
              </div>
              <input id="inputPassword" type="password" name="password" lay-verify="pass" value="" lay-verify="required"  placeholder="<?php echo lang('Password'); ?>" autocomplete="off" class="layui-input" lay-affix="eye">
            </div>
          </div>
      </div>
      </form>

    </div>
  </div>
</script>


<script type="text/html" id="memberinfo_tpl">
  <style>
    .header.layui-card-body{
      background-color: #fcf8e3;
      border-color: #faf3cd;
      color: #c09853;
      padding: 20px;
    }
  </style>
  <div>
    <div class="layui-card">
      <div class="layui-card-body header">
          <h3>温馨提示</h3>
          您的账号为: <a class="" target="_blank" href=""><?php echo !empty($account) ? htmlentities($account['username']) : ''; ?></a>
          <br>
          您已经登录   <a class="" target="_blank" href="https://www.funadmin.com">  FunAdmin  </a>云平台账号，<a class="" target="_blank" href="https://www.funadmin.com">  点击查看您的订单  </a>
      </div>
    </div>
  </div>
</script>

<button type="button" class="layui-btn layui-btn-sm" id="importFile" value="离线安装" style="display: none"/>
<script>
    var auth = <?php echo htmlentities($auth); ?>;
</script>



</div>
</body>
</html>
<!--[if lt IE 9]>
<script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
<script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

<script defer src="/static/require.min.js?v=<?php echo syscfg('site','site_version'); ?>" data-main="/static/js/require-backend<?php echo syscfg('site','app_debug')?'':'.min'; ?>.js?v=<?php echo syscfg('site','app_debug')?time():syscfg('site','site_version'); ?>" charset="utf-8"></script>
