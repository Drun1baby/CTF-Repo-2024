<?php /*a:3:{s:47:"/var/www/html/app/install/view/index/step4.html";i:1686239151;s:51:"/var/www/html/app/install/view/index/step-base.html";i:1686239151;s:45:"/var/www/html/app/install/view/index/css.html";i:1686239151;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>安装完成 - FunAdmin管理系统安装</title>
    <meta property="og:keywords" content="FunAdmin Layui ThinkPHP6 Requirejs 管理框架" />
<meta property="og:description" content="FunAdmin是一款基于ThinkPHP6+Layui的敏捷后台开发框架" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="format-detection" content="telephone=no"> <meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
<link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css" />
<script src="/static/plugins/layui/layui.js" v="2.7.2" e="layui"></script>
<script type="text/javascript" src="/static/plugins/jquery/jquery-3.6.0.min.js"></script>
<style>::-webkit-input-placeholder {
    color: #ccc
}

::-webkit-scrollbar {
    width: 5px !important;
    height: 6px !important;
    background: #ffffff !important;
    cursor: pointer !important
}

::-webkit-scrollbar-thumb {
    background-color: #9c9da0;
    -webkit-border-radius: 2em;
    -moz-border-radius: 2em;
    border-radius: 2em
}

::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 5px rgba(240, 240, 240, .5) !important;
    border-radius: 0 !important;
    background: rgba(240, 240, 240, 0.5) !important;
    cursor: pointer !important
}
.layui-elem-quote{
    border-left: 5px solid #1e9fff!important;
}
.layui-btn-danger {
    background-color: #f76d6d !important
}

.layui-red {
    color: #f76d6d;
    font-size: 18px
}

.layui-container {
    max-width: 1024px !important;
    margin: 10px auto
}

.layui-container .install-h1 {
    line-height: 60px;
    color: #393D49;
    font-size: 28px;
    font-weight: 300;
    text-align: center
}

.layui-elem-quote {
    margin-bottom: 20px
}

.layui-elem-quote h1 {
    font-size: 24px;
    font-weight: 300;
    margin-bottom: 20px
}

.btn-box {
    text-align: center;
    margin: 30px 0
}

.layui-elem-quote > p {
    margin-bottom: 10px
}

.layui-elem-quote > p a {
    color: #1e9fff
}

.layui-elem-quote > p a:hover {
    color: #e86c6c
}

.protocol {
    width: 100%;
    height: 400px;
    padding: 10px 20px;
    background-color: #fff;
    overflow-y: scroll;
    box-sizing: border-box
}

.protocol h3 {
    text-align: center;
    font-size: 18px;
    margin: 10px 0 15px
}

.protocol h4 {
    font-size: 16px;
    margin-top: 10px;
    color: #333
}

.protocol p {
    line-height: 1.7;
    color: #555
}

.protocol span {
    margin-top: 20px;
    display: block;
    color: #999;
    font-size: 12px
}

input {
    -webkit-writing-mode: horizontal-tb !important;
    text-rendering: auto;
    color: #7E96B3;
    letter-spacing: normal;
    word-spacing: normal;
    text-transform: none;
    text-indent: 0px;
    text-shadow: none;
    display: inline-block;
    text-align: start;
    -webkit-appearance: textfield;
    background-color: rgb(255, 255, 255);
    -webkit-rtl-ordering: logical;
    cursor: text;
    margin: 0em;
    font: 400 13.3333px Arial;
    padding: 1px 0px;
    border-width: 2px;
    border-style: inset;
    border-color: rgb(118, 118, 118);
    border-image: initial;
    border-radius: 2px
}

input::-webkit-input-placeholder {
    color: #aab2bd;
    font-size: 12px
}

.layui-form-item {
    margin-bottom: 10px
}

.layui-form-item input:focus {
    background: #fff;
    color: #444;
    outline: none;
    border-color: #FF5722 !important
}

.layui-notice {
    text-align: center
}
#layui-success, .layui-success{
    background: #1e9fff;
    color: #fff;
    padding: 15px 20px;
    border-radius: 4px;
    margin-bottom: 20px
}
#layui-error, .layui-error, , #layui-warmtips, .layui-warmtips {
    background: #f76d6d;
    color: #fff;
    padding: 15px 20px;
    border-radius: 4px;
    margin-bottom: 20px
}

#layui-error a, .layui-error a {
    color: white;
    text-decoration: underline
}

#layui-warmtips {
    background: #ffcdcd;
    font-size: 14px;
    color: #f76d6d
}

#layui-warmtips a {
    background: #ffffff7a;
    display: block;
    height: 30px;
    line-height: 30px;
    margin-top: 10px;
    color: #f76d6d;
    border-radius: 3px
}

.submit {
    text-align: center
}

.footer {
    text-align: center
}

@media screen and(max-width: 1024px) {
    .layui-container {
        width: 100%
    }
}

@media screen and(max-width: 768px) {
    .layui-container {
        max-width: 100%
    }
}</style>
</head>
<body>
<div class="layui-container">
    <?php if((session('admin_install'))): ?>
    <h1 class="install-h1">完成</h1>
    <blockquote class="layui-elem-quote" style="text-align:center">
        <h1>安装成功</h1>
        <p>账号:&nbsp;<?php echo session('admin_install.username'); ?>&nbsp;密码:&nbsp;<?php echo session('admin_install.password'); ?>&nbsp;</p>
        <p style="color: red;">为了安全，请记得要删除 /app/install</p>
        <p style="color: red;">请牢记后台登录地址：<a href="http://<?php echo request()->host(); ?>/backend" >http://<?php echo request()->host(); ?>/backend</a></p>
    </blockquote>
    <div class="btn-box">
        <a href="/" class="layui-btn layui-btn-normal layui-btn-radius pre">前往前台浏览</a>
        <a href="javascript:void(0)" class="layui-btn layui-btn-danger layui-btn-radius next">后台登录</a>
    </div>
    <?php else: ?>
    <script>window.location.href='/';</script>
    <?php endif; ?>
</div>


<script>
    layui.use('layer', function(){
        var $ = layui.jquery, layer = layui.layer;
        // 判断是否通过
        $(document).on("click",'.next',function(){
            $.post('')
                    .done(function (res) {
                        if (res.code>0) {
                            window.location.href = "http://<?php echo request()->host(); ?>/"+'backend';
                        }
                        layer.close(load)
                    })
                    .fail(function (data) {

                    });
            return false;
        });
    });
</script>
</body>
</html>