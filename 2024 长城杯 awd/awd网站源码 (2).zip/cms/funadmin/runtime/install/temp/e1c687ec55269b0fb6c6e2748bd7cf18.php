<?php /*a:3:{s:47:"/var/www/html/app/install/view/index/step3.html";i:1686239151;s:51:"/var/www/html/app/install/view/index/step-base.html";i:1686239151;s:45:"/var/www/html/app/install/view/index/css.html";i:1686239151;}*/ ?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>数据库配置 - FunAdmin开源系统安装</title>
    <meta property="og:keywords" content="FunAdmin Layui ThinkPHP6 Requirejs 管理框架" />
<meta property="og:description" content="FunAdmin是一款基于ThinkPHP6+Layui的敏捷后台开发框架" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="format-detection" content="telephone=no"> <meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/>
<link rel="stylesheet" type="text/css" href="/static/plugins/layui/css/layui.css" />
<script src="/static/plugins/layui/layui.js" v="2.7.2" e="layui"></script>
<script type="text/javascript" src="/static/plugins/jquery/jquery-3.6.0.min.js"></script>
<style>::-webkit-input-placeholder {
    color: #ccc
}

::-webkit-scrollbar {
    width: 5px !important;
    height: 6px !important;
    background: #ffffff !important;
    cursor: pointer !important
}

::-webkit-scrollbar-thumb {
    background-color: #9c9da0;
    -webkit-border-radius: 2em;
    -moz-border-radius: 2em;
    border-radius: 2em
}

::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 5px rgba(240, 240, 240, .5) !important;
    border-radius: 0 !important;
    background: rgba(240, 240, 240, 0.5) !important;
    cursor: pointer !important
}
.layui-elem-quote{
    border-left: 5px solid #1e9fff!important;
}
.layui-btn-danger {
    background-color: #f76d6d !important
}

.layui-red {
    color: #f76d6d;
    font-size: 18px
}

.layui-container {
    max-width: 1024px !important;
    margin: 10px auto
}

.layui-container .install-h1 {
    line-height: 60px;
    color: #393D49;
    font-size: 28px;
    font-weight: 300;
    text-align: center
}

.layui-elem-quote {
    margin-bottom: 20px
}

.layui-elem-quote h1 {
    font-size: 24px;
    font-weight: 300;
    margin-bottom: 20px
}

.btn-box {
    text-align: center;
    margin: 30px 0
}

.layui-elem-quote > p {
    margin-bottom: 10px
}

.layui-elem-quote > p a {
    color: #1e9fff
}

.layui-elem-quote > p a:hover {
    color: #e86c6c
}

.protocol {
    width: 100%;
    height: 400px;
    padding: 10px 20px;
    background-color: #fff;
    overflow-y: scroll;
    box-sizing: border-box
}

.protocol h3 {
    text-align: center;
    font-size: 18px;
    margin: 10px 0 15px
}

.protocol h4 {
    font-size: 16px;
    margin-top: 10px;
    color: #333
}

.protocol p {
    line-height: 1.7;
    color: #555
}

.protocol span {
    margin-top: 20px;
    display: block;
    color: #999;
    font-size: 12px
}

input {
    -webkit-writing-mode: horizontal-tb !important;
    text-rendering: auto;
    color: #7E96B3;
    letter-spacing: normal;
    word-spacing: normal;
    text-transform: none;
    text-indent: 0px;
    text-shadow: none;
    display: inline-block;
    text-align: start;
    -webkit-appearance: textfield;
    background-color: rgb(255, 255, 255);
    -webkit-rtl-ordering: logical;
    cursor: text;
    margin: 0em;
    font: 400 13.3333px Arial;
    padding: 1px 0px;
    border-width: 2px;
    border-style: inset;
    border-color: rgb(118, 118, 118);
    border-image: initial;
    border-radius: 2px
}

input::-webkit-input-placeholder {
    color: #aab2bd;
    font-size: 12px
}

.layui-form-item {
    margin-bottom: 10px
}

.layui-form-item input:focus {
    background: #fff;
    color: #444;
    outline: none;
    border-color: #FF5722 !important
}

.layui-notice {
    text-align: center
}
#layui-success, .layui-success{
    background: #1e9fff;
    color: #fff;
    padding: 15px 20px;
    border-radius: 4px;
    margin-bottom: 20px
}
#layui-error, .layui-error, , #layui-warmtips, .layui-warmtips {
    background: #f76d6d;
    color: #fff;
    padding: 15px 20px;
    border-radius: 4px;
    margin-bottom: 20px
}

#layui-error a, .layui-error a {
    color: white;
    text-decoration: underline
}

#layui-warmtips {
    background: #ffcdcd;
    font-size: 14px;
    color: #f76d6d
}

#layui-warmtips a {
    background: #ffffff7a;
    display: block;
    height: 30px;
    line-height: 30px;
    margin-top: 10px;
    color: #f76d6d;
    border-radius: 3px
}

.submit {
    text-align: center
}

.footer {
    text-align: center
}

@media screen and(max-width: 1024px) {
    .layui-container {
        width: 100%
    }
}

@media screen and(max-width: 768px) {
    .layui-container {
        max-width: 100%
    }
}</style>
</head>
<body>
<div class="layui-container">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-panel">
                <div class="layui-card">
                    <h1 class="install-h1">开始安装</h1>
                    <div class="layui-card-body">
                        <div class="layui-tabs-control">
                            <div class="layui-tab-item layui-show">
                                <div class="layui-row" >
                                    <form class="layui-form" action="<?php echo url('index/step3'); ?>" >
                                        <div class="layui-notice">
                                            <div id="layui-error" class=" <?php if(!file_exists($config['lockFile'])): ?> layui-hide <?php endif; ?>">
                                            <?php if(file_exists($config['lockFile'])): ?>
                                                已经安装了,如果需要重新安装请先删除public/install.lock
                                            <?php endif; ?>
                                            </div>
                                            <div id="layui-success" class="layui-hide"></div>
                                            <div id="layui-warmtips"class="layui-hide" ></div>
                                        </div>
                                        <div id="fun-box" style="">
                                            <div class="layui-form-item form-main">
                                                <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
                                                    <legend>数据库设置</legend>
                                                </fieldset>
                                                <div class="layui-form-item">
                                                    <div class="layui-form-item">
                                                        <label class="layui-form-label required">主机地址</label>
                                                        <div class="layui-input-block">
                                                            <input type="text" name="hostname" class="layui-input" lay-verify="required" title="请输入主机地址、端口号可选，容器名，docker版本请填写容器名 mysql"
                                                                   placeholder="请输入主机地址、端口号可选，容器名，docker版本请填写容器名 mysql" value="127.0.0.1">
                                                        </div>
                                                    </div>
                                                    <div class="layui-form-item">
                                                        <label class="layui-form-label required">数据库名</label>
                                                        <div class="layui-input-block">
                                                            <input type="text" name="database" value="funadmin" class="layui-input"
                                                                   lay-verify="required" placeholder="请输入数据库名">
                                                        </div>
                                                    </div>
                                                    <div class="layui-form-item">
                                                        <label class="layui-form-label required">数据表前缀</label>
                                                        <div class="layui-input-block">
                                                            <input type="text" name="prefix" value="fun_" class="layui-input"
                                                                   lay-verify="required" placeholder="请设置数据表前缀">
                                                        </div>
                                                    </div>
                                                    <div class="layui-form-item">
                                                        <label class="layui-form-label required">用户名</label>
                                                        <div class="layui-input-block">
                                                            <input type="text" name="username" value="root" class="layui-input" lay-verify="required"
                                                                   placeholder="请输入MYSQL用户名">
                                                        </div>
                                                    </div>
                                                    <div class="layui-form-item">
                                                        <label class="layui-form-label required">密码</label>
                                                        <div class="layui-input-block">
                                                            <input type="password" name="password"  value="root" class="layui-input" lay-verify="required"
                                                                   placeholder="请输入数据库密码" autocomplete="off">
                                                        </div>
                                                    </div>
                                                    <div class="layui-form-item">
                                                        <label class="layui-form-label required">端口</label>
                                                        <div class="layui-input-block">
                                                            <input type="port" name="port" class="layui-input" lay-verify="required"
                                                                   placeholder="MYSQL端口" value="3306" autocomplete="off">
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="layui-form-item form-main">
                                                <fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
                                                    <legend>账户设置</legend>
                                                </fieldset>
                                                <div class="layui-form-item">
                                                    <div class="layui-form-item">
                                                        <label class="layui-form-label required">用户名</label>
                                                        <div class="layui-input-block">
                                                            <input type="text" name="adminUserName" value="admin" lay-verify="required"
                                                                   class="layui-input" placeholder="请输入管理员账号">
                                                        </div>
                                                    </div>

                                                    <div class="layui-form-item">
                                                        <label class="layui-form-label required">密码</label>
                                                        <div class="layui-input-block">
                                                            <input type="password" name="adminPassword" lay-verify="required|pass" class="layui-input"
                                                                   placeholder="请输入密码">
                                                        </div>
                                                    </div>
                                                    <div class="layui-form-item">
                                                        <label class="layui-form-label required">重复密码</label>
                                                        <div class="layui-input-block">
                                                            <input type="password" name="rePassword" lay-verify="required|pass" class="layui-input"
                                                                   placeholder="请再次输入密码">
                                                        </div>
                                                    </div>
                                                    <div class="layui-form-item">
                                                        <label class="layui-form-label">Email</label>
                                                        <div class="layui-input-block">
                                                            <input type="text" name="email" value="admin@admin.com" lay-verify="required|email"
                                                                   class="layui-input" placeholder="请输入管理员邮箱">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="layui-form-item submit">
                                                <a type="submit" class="layui-btn layui-btn-danger layui-btn-radius" href="/install.php/index/step2">上一步</a>
                                                <button type="submit" class="layui-btn layui-btn-normal layui-btn-radius" lay-submit="" lay-filter="submit" style="text-align:center;">立即安装</button>
                                            </div>
                                        </div>
                                    </form>
                                    <br>
                                    <div class="layui-footer footer">
                                        <h5>Powered By <font>FunAdmin</font><font class="orange"></font></h5>
                                        <h6>版权所有 2018-2022 © <a href="https://www.funadmin.com" target="_blank">FunAdmin</a></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!--   -->
</div>
<script type="text/javascript">
    layui.use(['layer','jquery','form'],function (res) {
        var layer = layui.layer,$ = layui.$,form=layui.form;
        //监听提交
        form.on('submit(submit)', function(data){
            if ("<?php echo file_exists($config['lockFile']); ?>")
            {
                layer.msg('已经安装了,如果需要重新安装请先删除public/install.lock');
                return false;
            }
            var that = $(this);
            var load = layer.load();
            $('#layui-error').addClass('layui-hide')
            $('.layui-btn-radius').addClass('layui-hide');
            that.text('安装中...').prop('disabled', true);
            $.post('', data.field)
                .done(function (res) {
                    if (res.code>0) {
                        $('#layui-error').addClass('layui-hide');
                        $('#layui-success').removeClass('layui-hide').text(res.msg);
                        $("#layui-fun-box").remove();
                        that.remove();
                        layer.msg('安装成功', {
                            icon: 1,
                            time: 2000 //2秒关闭（如果不配置，默认是3秒）
                        }, function(){
                            window.location.href='/install.php/index/step4';
                        });
                    } else {
                        $('#layui-error').removeClass('layui-hide')
                        $('#layui-error').text(res.msg);
                        $('.layui-btn-radius').removeClass('layui-hide');
                        that.text('立即安装').prop('disabled', false);
                        $("html,body").animate({
                            scrollTop: 0
                        }, 500);
                    }
                    layer.close(load)
                })
                .fail(function (data) {
                    $('#layui-error').show().text('发生错误:\n\n' + data.responseText);
                    $('.layui-btn-radius').removeClass('layui-hide');

                    $("html,body").animate({
                        scrollTop: 0
                    }, 500);
                    layer.close(load)
                });
            return false;
        });

    })
</script>
</body>
</html>