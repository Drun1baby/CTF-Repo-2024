<?php
//000000000000
 exit();?>
a:4:{s:8:"autoload";b:1;s:5:"hooks";a:0:{}s:5:"route";a:0:{}s:7:"service";a:0:{}}