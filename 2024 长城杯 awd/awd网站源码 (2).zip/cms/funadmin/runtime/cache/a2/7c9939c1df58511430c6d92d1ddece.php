<?php
//000000003600
 exit();?>
s:34:"FunAdmin,LAYUI,THINKPHP6,RequireJS";