<?php
//000000003600
 exit();?>
a:11:{s:16:"upload_file_type";s:54:"mp4,mp3,png,gif,jpg,jpeg,webp,rar,zip,php,csv,xls,xlsx";s:15:"upload_file_max";s:4:"8192";s:12:"upload_water";s:0:"";s:21:"upload_water_position";s:1:"9";s:18:"upload_water_alpha";s:0:"";s:18:"upload_water_thumb";s:0:"";s:17:"upload_water_size";s:0:"";s:18:"upload_water_color";s:0:"";s:13:"upload_driver";s:5:"local";s:12:"upload_chunk";s:1:"1";s:16:"upload_chunksize";s:3:"500";}