<?php
//000000003600
 exit();?>
a:20:{s:9:"site_name";s:20:"FunAdmin管理系统";s:10:"site_phone";s:10:"1888888888";s:10:"site_state";s:18:"0:关闭
1:开启";s:9:"site_logo";s:89:"https://funcdn.funadmin.com/storage/uploads/20210728/ee2945775d13f6aff511307d689037d7.png";s:16:"site_mobile_logo";s:20:"site_mobile_logo.png";s:11:"site_logowx";s:15:"site_logowx.jpg";s:8:"site_icp";s:1:"2";s:11:"site_tel400";s:11:"40002541852";s:10:"site_email";s:18:"15151711601@qq.com";s:14:"site_copyright";s:48:"© 2018-2030 FunAdmin.com - 版权所有FunAdmin";s:9:"app_debug";s:1:"0";s:12:"site_tabicon";s:1:"0";s:12:"site_licence";s:0:"";s:11:"site_domain";s:23:"http://www.funadmin.com";s:14:"site_seo_title";s:8:"FunAdmin";s:17:"site_seo_keywords";s:24:"FunAdmin,LAYUI,THINKPHP6";s:13:"site_seo_desc";s:34:"FunAdmin,LAYUI,THINKPHP6,RequireJS";s:12:"site_version";s:3:"3.0";s:10:"site_theme";s:1:"1";s:17:"site_reloadiframe";s:18:"0:关闭
1:开启";}