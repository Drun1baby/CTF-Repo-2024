<?php

return [
    //权限开关
    "auth_on" =>true,
    //超级管理员id

    'superAdminId'=>1,
    //是否演示站点
    'isDemo'=>0,
    //版本
    'version' => 'x.x.x',

    'version_data' => '202x0x0x',

    'layui_version' => '2.8.4',

    'ip_check'=>false,

    'publicAjaxUrl'=>['ajax/uploads', 'ajax/getAttach', 'sys.attach/selectfiles','ajax/export','ajax/import']
];


