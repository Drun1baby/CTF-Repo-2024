<?php

return array(
    'autoload' => true,
    'hooks' =>
        array(),
    'route' =>
        array(),
    'service' =>
        array(),
);